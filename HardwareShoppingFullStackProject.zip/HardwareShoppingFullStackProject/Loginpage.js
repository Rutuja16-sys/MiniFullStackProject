// src/app/login/page.js
"use client";

import { useState } from "react";

export default function LoginPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [message, setMessage] = useState("");

  const handleLogin = async (e) => {
    e.preventDefault();

    try {
      const res = await fetch("http://localhost:5000/api/login", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",   // ✅ needed
        },
        body: JSON.stringify({ email, password }),  // ✅ body must be JSON string
      });


      const data = await res.json();

      if (res.ok) {
        setMessage("✅ Login successful!");
        window.location.href = "/products"; // redirect to products page
      } else {
        setMessage("❌ " + data.message);
      }
    } catch (error) {
      setMessage("⚠️ Something went wrong, try again.");
      console.error("Login error:", error);
    }
  };

  return (
    <main style={{ display: "flex", justifyContent: "center", alignItems: "center", height: "100vh" }}>
      <form onSubmit={handleLogin} style={{ display: "flex", flexDirection: "column", gap: "1rem" }}>
        <h1>Login Page 🔑</h1>
        <input type="email" placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} required />
        <input type="password" placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} required />
        <button type="submit">Login</button>
        <p>{message}</p>
      </form>
    </main>
  );
}
