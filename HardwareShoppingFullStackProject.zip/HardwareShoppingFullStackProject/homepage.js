// src/app/page.js
export default function HomePage() {
  return (
    <main style={{ textAlign: "center", marginTop: "50px" }}>
      <h1>Welcome to My App 🚀</h1>
      <a href="/login">Go to Login</a>
    </main>
  );
}
