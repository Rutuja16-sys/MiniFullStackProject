// backend-server.js
const express = require("express");
 const cors = require("cors");
 const bodyParser = require("body-parser");

 const app = express();

 // Enable CORS for Next.js frontend (port 3002 in your case)
 app.use(
   cors({
     origin: "http://localhost:3004",
     methods: ["GET", "POST"],
     allowedHeaders: ["Content-Type"],
   })
 );

 // Parse JSON bodies
 app.use(bodyParser.json());

 // Dummy user
 const USER = { email: "test@example.com", password: "123456" };

 // Dummy products
 const products = [
   { id: 1, name: "Laptop", price: 75000 },
   { id: 2, name: "Smartphone", price: 40000 },
   { id: 3, name: "Headphones", price: 5000 },
 ];

 // Login API
 app.post("/api/login", (req, res) => {
   console.log("Login attempt:", req.body); // Debugging log
   const { email, password } = req.body;
   if (email === USER.email && password === USER.password) {
     return res.json({ success: true });
   }
   res.status(401).json({ success: false, message: "Invalid credentials" });
 });

 // Products API
 app.get("/api/products", (req, res) => {
   res.json(products);
 });

 const PORT = 5000;
 app.listen(PORT, () =>
   console.log(`✅ Express API running on http://localhost:${PORT}`)
 );
